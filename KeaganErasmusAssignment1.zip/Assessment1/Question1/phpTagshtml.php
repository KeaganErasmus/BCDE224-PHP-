<!Doctype html>

<head>
    <title>Escaping html Tags</title>
</head>

<body>
    
    <?php
    // Escaping the html tags to write PHP code
    echo "PHP is working!";
    ?>

    <?php
    
    echo "Hello world";
    echo "<br>";
    echo "let's learn PHP";
    
    ?>
</body>