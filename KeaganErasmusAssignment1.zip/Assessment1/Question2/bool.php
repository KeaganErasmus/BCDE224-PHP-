<?php
    $isActive = TRUE;

    if ($isActive){
        echo "The object is active";
    }else{
        echo "It seems that the object is inactive";
    }
?>