<?php

    class Calculation{
        var $num1;
        var $num2;

        function add(){
            return $this->num1 + $this->num2;
        }
    }

?>