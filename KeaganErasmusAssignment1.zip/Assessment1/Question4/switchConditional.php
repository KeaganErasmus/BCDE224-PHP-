<?php

$condition = 5;
switch ($condition) {
case 1:
    echo "not 5";
    break;

case 5:
    echo "it is a 5";
    break;

default:
    echo "invalid input";
    break;
}
?>