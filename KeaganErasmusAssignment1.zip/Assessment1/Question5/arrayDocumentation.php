<?php

$some_array = array(
    'foo'  => 'bar',
    'spam' => 'ham',
);

foreach($some_array as $key => $val){
    echo "{$key} => {$val} ";;
}
?>