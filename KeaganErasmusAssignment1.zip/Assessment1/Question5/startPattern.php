<?php  
    for($row=0; $row<=5; $row++){  
        for($col=5-$row ;$col>=1; $col--){  
            echo "* ";  
    }  
    echo "<br>";  
}  
?>  