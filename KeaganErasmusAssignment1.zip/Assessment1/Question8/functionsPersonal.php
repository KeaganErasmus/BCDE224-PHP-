<?php

function makeSomethingToEat($type){
    return "Making some $type<br/>";
}

echo makeSomethingToEat("sandwiches");
echo makeSomethingToEat("Milo");

?>