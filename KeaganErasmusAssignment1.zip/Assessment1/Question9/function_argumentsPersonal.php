<?php

    function multiply_num($num1, $num2){
        echo "The multiplication of ". $num1 . " and " . $num2 . " is</br>";
        return ($num1 * $num2);
    }

    echo multiply_num(5,4);

?>